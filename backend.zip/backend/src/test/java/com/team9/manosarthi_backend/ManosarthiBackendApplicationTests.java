package com.team9.manosarthi_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ManosarthiBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
