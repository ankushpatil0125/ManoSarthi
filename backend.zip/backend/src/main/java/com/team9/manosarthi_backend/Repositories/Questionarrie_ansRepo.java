package com.team9.manosarthi_backend.Repositories;

import com.team9.manosarthi_backend.Entities.Questionarrie_ans;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Questionarrie_ansRepo extends JpaRepository<Questionarrie_ans,Integer> {
}
