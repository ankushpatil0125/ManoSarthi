package com.team9.manosarthi_backend.Repositories;

import com.team9.manosarthi_backend.Entities.MedicalQueAns;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MedicalQueAnsRepo extends JpaRepository<MedicalQueAns,Integer> {
}
