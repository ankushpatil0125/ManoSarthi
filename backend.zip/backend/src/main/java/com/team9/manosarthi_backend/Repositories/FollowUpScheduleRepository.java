package com.team9.manosarthi_backend.Repositories;

import com.team9.manosarthi_backend.Entities.FollowUpSchedule;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FollowUpScheduleRepository extends JpaRepository<FollowUpSchedule,Integer> {
}
